import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class UserRegistration extends JFrame {
    JTextField nameField, phoneField;
    JButton registerButton;

    public UserRegistration() {
        setTitle("User Registration");
        setSize(300, 200);
        setLayout(null);

        JLabel nameLabel = new JLabel("User Name:");
        nameLabel.setBounds(20, 20, 100, 25);
        add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(120, 20, 150, 25);
        add(nameField);

        JLabel phoneLabel = new JLabel("Phone No:");
        phoneLabel.setBounds(20, 60, 100, 25);
        add(phoneLabel);

        phoneField = new JTextField();
        phoneField.setBounds(120, 60, 150, 25);
        add(phoneField);

        registerButton = new JButton("Register");
        registerButton.setBounds(90, 100, 100, 30);
        add(registerButton);

        registerButton.addActionListener(e -> registerUser());

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void registerUser() {
        String name = nameField.getText();
        String phone = phoneField.getText();

        try (Connection conn = DBConnection.getConnection()) {
            String query = "INSERT INTO APP_USER (USER_ID, USER_NAME, PHONE_NO) VALUES (APP_USER_SEQ.NEXTVAL, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, name);
            stmt.setString(2, phone);

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "User Registered Successfully!");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new UserRegistration();
    }
}
